/*This program demonstrates the use of  a text-based, menu-driven program that allows the user to choose whether to add,
subtract, multiply or divide two numbers. The program should then input two double values
from the user, perform the appropriate calculation and display the result. Use an array of
function pointers in which each pointer represents a function that returns void and receives
two double parameters. The corresponding functions should each display messages
indicating which calculation was performed, the values of the parameters and the result of
the calculation.*/

//----------------------------------------------------MANVI KOUL--------------------------------------------------------------------
//----------------------------------------------------Project Assignment------------------------------------------------------------
//--------------------------------------------Submission Date:-14 February2022------------------------------------------------------
//--------------------------------------------------------SET-"C"-------------------------------------------------------------------
//----------------------------------------------------------Q2----------------------------------------------------------------------
 
 

#include <stdio.h>
    

 
int sum(int  n1, int  n2);
int sub(int  n1, int  n2);
int mul(int  n1, int  n2);
int div(int  n1, int  n2);

int main() 
{  
   
  int  x, y, choice, result;
  int  (*ope[4])(int ,int );                                        //defines array of function pointers
  ope[1] = sum;
  ope[2] = sub;
  ope[3] = mul;
  ope[4] = div;
  printf("Enter 1st number: \n");
  scanf("%d", &x);
  printf("Enter 2nd number: \n");
  scanf("%d", &y);
  printf("The passed parameters are %d and %d\n",x,y);
  printf("Enter 1 to sum\n2 to subtract\n3 to multiply\n4 to divide: ");
  scanf("%d", &choice);
  result = ope[choice](x, y);                                       //it will run function which has been entered by user
  printf("OUTPUT:-%d", result);
return 0;
}
int  sum(int  x, int  y)
{
printf("Addition performed sucessfully  :)\n");
 
return(x + y);
}
int sub(int  x, int  y)
{
printf("Subtraction performed sucessfully  :)\n");
 
return(x - y);
}
int  mul(int  x, int  y) 
{
printf("Multiplication performed sucessfully  :)\n");
 
return(x * y);
}
int div(int  x, int  y) 
{
if (y != 0){
printf("Division performed successfully :)\n");
return (x / y);}
  
  
else 
return 0;
}

