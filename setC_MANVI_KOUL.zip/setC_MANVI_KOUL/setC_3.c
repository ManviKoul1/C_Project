/*
3.Write a program that uses random number generation to create sentences. The program should use four arrays of pointers to char called article, noun, verb and preposition. The program should create a sentence by selecting a word at random from each array in the following order: article, noun, verb, preposition. As each word is picked, itshould be concatenated to the previous words in an array large enough to hold the entire sentence. The words should be separated by spaces. When the final sentence is output, it should start with a capital letter and end with a period. The program should generate 20 such sentences. The arrays should be filled as follows: The article array should contain the articles "the", "a", "one", "some" and "any"; the noun array should contain the nouns "boy","girl", "dog", "town" and "car"; the verb array should contain the verbs "drove", "jumped","ran", "walked" and "skipped"; the preposition array should contain the prepositions "to","from", "over", "under" and "on". */

//----------------------------------------------------MANVI KOUL--------------------------------------------------------------------
//----------------------------------------------------Project Assignment------------------------------------------------------------
//--------------------------------------------Submission Date:-14 February2022------------------------------------------------------
//--------------------------------------------------------SET-"C"-------------------------------------------------------------------
//----------------------------------------------------------Q3----------------------------------------------------------------------
 
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>

const int s_leng = 80,limit_sen = 20;                                        //variable being declared is pointing to a constantinteger

//defining according to the question
const char* article[] = {
"the", "a", "one", "some", "any"
};                      
const char* noun[] =  {
"boy", "girl", "dog", "town", "car"
};
const char* verb[] =  {
"drove", "jumped", "ran", "walked", "skipped"
};
const char* prepositions[] =  {
"to", "from", "over", "under", "on"
};
const int article_SIZE = sizeof(article)/sizeof(article[0]);                   //sizeof returns the number of bytes the array occupies.
const int noun_SIZE = sizeof(noun)/sizeof(noun[0]);
const int verb_SIZE = sizeof(verb)/sizeof(verb[0]);
const int prepositions_SIZE = sizeof(prepositions)/sizeof(prepositions[0]);
 

char* sent_making() {                                                          //for sentence making
printf("-----------------------------------------\n");
    char* sentence = calloc((s_leng+1), sizeof(char));                         //used for dynamic memory allocation with 2 arguments 
printf("-----------------------------------------\n");
strcat(sentence, article[rand()%article_SIZE]);                               //for joining sentences here using the strcat
strcat(sentence, " ");
  
strcat(sentence, noun[rand()%noun_SIZE]);
strcat(sentence, " ");

strcat(sentence, verb[rand()%verb_SIZE]);
strcat(sentence, " ");

strcat(sentence, prepositions[rand()%prepositions_SIZE]);
sentence[0] = toupper(sentence[0]);                                          //for making first letter capital

return sentence;
}

int main(int x, char* y[]) 
{
    srand(time(NULL));                                        //it initialises the seed of random each time to get different o/p
                                                              //time(NULL) uses srand for different seed

for(int i=0;i<limit_sen;i++)
{
        char* sentence = sent_making();
        printf("%s.\n", sentence);
        free(sentence);                                      //allows you to release blocks of memory which are used by calloc
} 

    return 0;
}
