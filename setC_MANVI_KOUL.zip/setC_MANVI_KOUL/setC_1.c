/*Telephone-Number Word Generator) Standard telephone keypads contain the digits 0 through 9. The numbers 2 through 9 each have three letters associated with them, as is indicated by the following table: 
Digit 
letter 
Digit Letter
2 
ABC 
6 MNO
3 
DEF 
7 PRS
4 
GHI 
8 TUV
5 
JKL 
9 WXY



Many people find it difficult to memorize phone numbers, so they use the correspondence between digits and letters to develop seven-letter words that correspond to their phone numbers. For example, a person whose telephone number is 686-2377 might use the correspondence indicated in the above table to develop the seven-letter word “NUMBERS.” Businesses frequently attempt to get telephone numbers that are easy for their clients to remember. If a business can advertise a simple word for its customers to dial, then, no doubt, the business will receive a few more calls. 
Each seven-letter word corresponds to exactly one seven-digit telephone number. The restaurant wishing to increase its take-home business could surely do so with the number 825-3688 (i.e., “TAKEOUT”). 
Each seven-digit phone number corresponds to many separate seven-letter words. Unfortu nately, most of these represent unrecognizable juxtapositions of letters. Write a C program that, given a seven-digit number, writes to a file every possible seven-letter word corresponding to that number. There are 2187 (3 to the seventh power) such words. Avoid phone numbers with the digits 0 and 1. */



//----------------------------------------------------MANVI KOUL--------------------------------------------------------------------
//----------------------------------------------------Project Assignment------------------------------------------------------------
//--------------------------------------------Submission Date:-14 February2022------------------------------------------------------
//--------------------------------------------------------SET-"C"-------------------------------------------------------------------
//----------------------------------------------------------Q1----------------------------------------------------------------------
 
 
  

#include <stdio.h>
int main(void)
{
  char buf[BUFSIZ], *p;                             //here we define char buffer for allocating space by using present char array into it
  printf("________________________________________\n");
  printf("______NOTE:-Do not use digit 0 & 1_______\n");
  printf("Enter a,b,c for printing no. 2\n");
  printf("Enter d,e,f for printing no. 3\n");
  printf("Enter g,h,i for printing no. 4\n");
  printf("Enter j,k,l for printing no. 5\n");
  printf("Enter m,n,o for printing no. 6\n");
  printf("Enter p,q,r for printing no. 7\n");
  printf("Enter s,t,u for printing no. 8\n");
  printf("Enter v,w,x,y,z for printing no. 9\n");
  printf("________________________________________\n");
  printf("Enter phone number using alphabets:- \n");
  fflush(stdout);

  fgets(buf,sizeof buf,stdin);                      //fgets for reading characters

  for (p = buf;*p;p++)
  {
    
    switch (*p)                              //using switch case to print no.
    {
      case 'a':
      case 'b':
      case 'c':
      printf("2");
      break;
      case 'd':
      case 'e':
      case 'f':
      printf("3");
      break;
      case 'g':
      case 'h':
      case 'i':
      printf("4");
      break;
      case 'j':
      case 'k':
      case 'l':
      printf("5");
      break;
      case 'm':
      case 'n':
      case 'o':
      printf("6");
      break;
      case 'p':
      case 'q':
      case 'r':
      case 's':
      printf("7");
      break;
      case 't':
      case 'u':
      case 'v':
      printf("8");
      break;
      case 'w':
      case 'x':
      case 'y':
      case 'z':
      printf("9");
      break;
      default:
      printf("\n\nExecuted successfully :)");

    }
  }

  return 0;
}






 

























